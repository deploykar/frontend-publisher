# Frontend Publisher — PaaS Deployment Platform

Python microservices that power the deployment pipeline for your PaaS.

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│  Frontend (React)                                               │
│  - User logs in via GitHub OAuth                                │
│  - Drag & drop stack card (React/Next/Vue)                      │
│  - Popup: select repo → add env vars → click Deploy             │
└──────────────────────────┬──────────────────────────────────────┘
                           │ POST /api/v1/deployments
                           ▼
┌──────────────────────────────────────────────────────────────────┐
│  Gateway Service (FastAPI :8000)                                  │
│  - Validates deployment payload                                   │
│  - Authenticates user (JWT with GitHub token)                     │
│  - Pushes job to Redis/Celery queue                               │
│  - Proxies GitHub API (list repos, branches)                      │
└──────────────────────────┬───────────────────────────────────────┘
                           │ Celery task
                           ▼
┌──────────────────────────────────────────────────────────────────┐
│  Redis (Queue + Registry)                                         │
└──────────┬───────────────────────────────────┬───────────────────┘
           │                                   │
           ▼                                   ▼
┌─────────────────────────┐     ┌──────────────────────────────────┐
│  Worker (Celery)         │     │  Webhook Service (FastAPI :8001)  │
│  - Clones repo           │     │  - Receives GitHub push events    │
│  - npm install + build   │     │  - Verifies HMAC signature        │
│  - Deploys output        │     │  - Looks up project in registry   │
│  - Registers project     │     │  - Triggers redeploy via queue    │
└─────────────────────────┘     └──────────────────────────────────┘
```

## Services

| Service   | Port | Description                                    |
|-----------|------|------------------------------------------------|
| Gateway   | 8000 | API for frontend — deploy, list repos, status  |
| Webhook   | 8001 | GitHub webhook receiver for auto-redeploy      |
| Worker    | —    | Celery worker that runs actual deployments     |
| Redis     | 6379 | Message broker + project registry              |

## Quick Start

```bash
# 1. Copy env file
cp .env.example .env
# Fill in your GitHub OAuth app credentials and secrets

# 2. Run everything
docker-compose up --build
```

## API Endpoints

### Gateway (`:8000`)

| Method | Endpoint                          | Description                  |
|--------|-----------------------------------|------------------------------|
| POST   | `/api/v1/deployments/`            | Create a new deployment      |
| GET    | `/api/v1/deployments/{id}/status` | Check deployment status      |
| GET    | `/api/v1/github/repos`            | List user's GitHub repos     |
| GET    | `/api/v1/github/repos/{o}/{r}/branches` | List repo branches   |

### Webhook (`:8001`)

| Method | Endpoint            | Description                    |
|--------|---------------------|--------------------------------|
| POST   | `/webhooks/github`  | GitHub push event receiver     |

## Deployment Payload (Frontend → Gateway)

```json
{
  "user_id": "user-123",
  "stack_type": "react",
  "github_repo_full_name": "username/my-app",
  "branch": "main",
  "env_vars": [
    {"key": "VITE_API_URL", "value": "https://api.example.com"},
    {"key": "VITE_APP_NAME", "value": "My App"}
  ],
  "build_command": "npm run build",
  "output_dir": "dist"
}
```

## Auto-Redeploy Flow

1. On first deploy, the worker registers the project in Redis
2. You configure a GitHub webhook pointing to `https://your-domain/webhooks/github`
3. When a user pushes to the tracked branch, GitHub sends a push event
4. Webhook service verifies the signature, looks up the project, triggers redeploy
5. Only the specific project for that repo gets redeployed — not others

## Setting Up GitHub Webhook

In your GitHub repo → Settings → Webhooks → Add webhook:
- **Payload URL**: `https://your-paas.dev/webhooks/github`
- **Content type**: `application/json`
- **Secret**: Same as `GITHUB_WEBHOOK_SECRET` in your `.env`
- **Events**: Just the `push` event
