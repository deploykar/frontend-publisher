"""
SQS Consumer — long-polls the deployment queue and processes jobs.
"""
import json
import time
import logging
import boto3
from worker.config import AWS_REGION, SQS_QUEUE_URL
from worker.tasks import run_deployment

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

sqs = boto3.client("sqs", region_name=AWS_REGION)


def poll_queue():
    """Long-poll SQS for deployment messages."""
    logger.info(f"Worker started. Polling queue: {SQS_QUEUE_URL}")

    while True:
        try:
            response = sqs.receive_message(
                QueueUrl=SQS_QUEUE_URL,
                MaxNumberOfMessages=1,
                WaitTimeSeconds=20,  # Long polling
                VisibilityTimeout=300,  # 5 min to process
            )

            messages = response.get("Messages", [])

            if not messages:
                continue

            for message in messages:
                body = json.loads(message["Body"])
                deployment_id = body.get("deployment_id", "unknown")
                logger.info(f"Processing deployment: {deployment_id}")

                try:
                    result = run_deployment(body)
                    logger.info(f"Deployment {deployment_id} completed: {result.get('status')}")

                    # Delete message from queue on success
                    sqs.delete_message(
                        QueueUrl=SQS_QUEUE_URL,
                        ReceiptHandle=message["ReceiptHandle"],
                    )
                except Exception as e:
                    logger.error(f"Deployment {deployment_id} failed: {e}")
                    # Message will become visible again after VisibilityTimeout
                    # and can be retried or sent to DLQ

        except KeyboardInterrupt:
            logger.info("Worker shutting down...")
            break
        except Exception as e:
            logger.error(f"Queue polling error: {e}")
            time.sleep(5)


if __name__ == "__main__":
    poll_queue()
