import os
import json
import subprocess
import shutil
import tempfile
import logging
import redis
from worker.config import REDIS_URL

logger = logging.getLogger(__name__)

_redis = redis.from_url(REDIS_URL)
REGISTRY_PREFIX = "project:"


def run_deployment(payload: dict) -> dict:
    """
    Main deployment task. Steps:
    1. Clone the repo
    2. Install dependencies
    3. Set env vars
    4. Run build command
    5. Deploy output to hosting (placeholder)
    6. Register project in registry for future webhook triggers
    """
    deployment_id = payload["deployment_id"]
    repo = payload["github_repo"]
    branch = payload.get("branch", "main")
    env_vars = payload.get("env_vars", {})
    build_command = payload.get("build_command", "npm run build")
    output_dir = payload.get("output_dir", "dist")
    github_token = payload.get("github_token")
    trigger = payload.get("trigger", "manual")

    work_dir = tempfile.mkdtemp(prefix=f"deploy-{deployment_id[:8]}-")

    try:
        # Step 1: Clone
        logger.info(f"[{deployment_id}] Cloning {repo}@{branch}")
        clone_url = f"https://x-access-token:{github_token}@github.com/{repo}.git"
        subprocess.run(
            ["git", "clone", "--depth", "1", "--branch", branch, clone_url, work_dir],
            check=True,
            capture_output=True,
            text=True,
        )

        # Step 2: Install dependencies
        logger.info(f"[{deployment_id}] Installing dependencies")
        package_json = os.path.join(work_dir, "package.json")
        if os.path.exists(package_json):
            subprocess.run(
                ["npm", "ci"],
                cwd=work_dir,
                check=True,
                capture_output=True,
                text=True,
            )

        # Step 3: Set env vars — write .env file
        if env_vars:
            env_file_path = os.path.join(work_dir, ".env")
            with open(env_file_path, "w") as f:
                for key, value in env_vars.items():
                    f.write(f"{key}={value}\n")

        # Step 4: Build
        logger.info(f"[{deployment_id}] Running build: {build_command}")
        build_env = os.environ.copy()
        build_env.update(env_vars)
        subprocess.run(
            build_command.split(),
            cwd=work_dir,
            check=True,
            capture_output=True,
            text=True,
            env=build_env,
        )

        # Step 5: Deploy output
        logger.info(f"[{deployment_id}] Deploying")
        build_output_path = os.path.join(work_dir, output_dir)
        if not os.path.exists(build_output_path):
            raise FileNotFoundError(
                f"Build output directory '{output_dir}' not found after build"
            )

        # TODO: Replace with actual deployment logic
        # e.g., upload to S3, push to CDN, copy to nginx serve dir
        deploy_url = f"https://{repo.replace('/', '-')}.your-paas.dev"

        # Step 6: Register project for webhook-based redeploys
        project_data = {
            "user_id": payload["user_id"],
            "stack_type": payload["stack_type"],
            "branch": branch,
            "env_vars": env_vars,
            "build_command": build_command,
            "output_dir": output_dir,
            "github_token": github_token,
            "deploy_url": deploy_url,
            "last_deployment_id": deployment_id,
        }
        _redis.set(f"{REGISTRY_PREFIX}{repo}", json.dumps(project_data))

        logger.info(f"[{deployment_id}] Live at {deploy_url}")
        return {
            "deployment_id": deployment_id,
            "status": "live",
            "url": deploy_url,
            "trigger": trigger,
            "repo": repo,
            "branch": branch,
        }

    except subprocess.CalledProcessError as e:
        logger.error(f"[{deployment_id}] Build failed: {e.stderr[:200] if e.stderr else ''}")
        return {
            "deployment_id": deployment_id,
            "status": "failed",
            "error": f"Command failed: {e.cmd}",
            "stderr": e.stderr[:500] if e.stderr else "",
        }
    except Exception as e:
        logger.error(f"[{deployment_id}] Error: {e}")
        return {
            "deployment_id": deployment_id,
            "status": "failed",
            "error": str(e),
        }
    finally:
        shutil.rmtree(work_dir, ignore_errors=True)
