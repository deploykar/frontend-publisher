"""
Project registry — stores which repos are linked to which deployments.
In production, replace with a proper database (Postgres, etc.).
For now, uses Redis as a simple key-value store.
"""
import json
import redis
from app.config import REDIS_URL

_redis = redis.from_url(REDIS_URL)

REGISTRY_PREFIX = "project:"


def register_project(repo_full_name: str, project_data: dict):
    """Register a project so webhooks know how to redeploy it."""
    key = f"{REGISTRY_PREFIX}{repo_full_name}"
    _redis.set(key, json.dumps(project_data))


def get_project(repo_full_name: str) -> dict | None:
    """Look up a registered project by repo name."""
    key = f"{REGISTRY_PREFIX}{repo_full_name}"
    data = _redis.get(key)
    if data:
        return json.loads(data)
    return None


def remove_project(repo_full_name: str):
    """Unregister a project."""
    key = f"{REGISTRY_PREFIX}{repo_full_name}"
    _redis.delete(key)
