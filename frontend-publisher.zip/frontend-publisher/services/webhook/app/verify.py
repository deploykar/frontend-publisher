import hmac
import hashlib
from app.config import GITHUB_WEBHOOK_SECRET


def verify_github_signature(payload_body: bytes, signature_header: str) -> bool:
    """
    Verify that the webhook payload was sent by GitHub
    using the HMAC SHA-256 signature.
    """
    if not GITHUB_WEBHOOK_SECRET:
        # If no secret configured, skip verification (dev mode)
        return True

    if not signature_header:
        return False

    # GitHub sends: sha256=<hex_digest>
    if not signature_header.startswith("sha256="):
        return False

    expected_signature = signature_header[7:]
    computed_signature = hmac.new(
        key=GITHUB_WEBHOOK_SECRET.encode("utf-8"),
        msg=payload_body,
        digestmod=hashlib.sha256,
    ).hexdigest()

    return hmac.compare_digest(computed_signature, expected_signature)
