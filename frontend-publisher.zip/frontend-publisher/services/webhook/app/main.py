import uuid
from fastapi import FastAPI, Request, HTTPException, Header
from typing import Optional
from app.verify import verify_github_signature
from app.registry import get_project
from app.queue import send_to_queue

app = FastAPI(
    title="Frontend Publisher - Webhook Service",
    description="Handles GitHub webhooks for auto-redeploy",
    version="1.0.0",
)


@app.post("/webhooks/github")
async def github_webhook(
    request: Request,
    x_hub_signature_256: Optional[str] = Header(None),
    x_github_event: Optional[str] = Header(None),
):
    """
    GitHub sends a POST here on every push event.
    We look up the project by repo name and trigger a redeploy via SQS.
    """
    body = await request.body()

    # Verify signature
    if not verify_github_signature(body, x_hub_signature_256 or ""):
        raise HTTPException(status_code=401, detail="Invalid signature")

    # Only handle push events
    if x_github_event != "push":
        return {"message": f"Ignored event: {x_github_event}"}

    payload = await request.json()

    repo_full_name = payload.get("repository", {}).get("full_name")
    branch_ref = payload.get("ref", "")  # e.g. "refs/heads/main"
    pushed_branch = branch_ref.replace("refs/heads/", "")

    if not repo_full_name:
        raise HTTPException(status_code=400, detail="Missing repository info")

    # Look up the registered project
    project = get_project(repo_full_name)
    if not project:
        return {"message": f"No project registered for {repo_full_name}, skipping"}

    # Only redeploy if the push is to the tracked branch
    if project.get("branch") and project["branch"] != pushed_branch:
        return {
            "message": f"Push to {pushed_branch}, but project tracks {project['branch']}. Skipping."
        }

    # Trigger redeploy via SQS
    deployment_id = str(uuid.uuid4())
    job_payload = {
        "deployment_id": deployment_id,
        "user_id": project["user_id"],
        "stack_type": project["stack_type"],
        "github_repo": repo_full_name,
        "branch": pushed_branch,
        "env_vars": project.get("env_vars", {}),
        "build_command": project.get("build_command", "npm run build"),
        "output_dir": project.get("output_dir", "dist"),
        "github_token": project.get("github_token"),
        "trigger": "github_push",
        "commit_sha": payload.get("after"),
    }

    send_to_queue(job_payload, deployment_id)

    return {
        "message": f"Redeploy triggered for {repo_full_name}",
        "deployment_id": deployment_id,
    }


@app.get("/health")
async def health():
    return {"status": "ok", "service": "webhook"}
