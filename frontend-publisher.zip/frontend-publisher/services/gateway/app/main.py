from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routes import deploy, github, oauth

app = FastAPI(
    title="Frontend Publisher - Gateway",
    description="Deployment gateway service for the PaaS platform",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Restrict in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(oauth.router)
app.include_router(deploy.router)
app.include_router(github.router)


@app.get("/health")
async def health():
    return {"status": "ok", "service": "gateway"}
