from pydantic import BaseModel, Field
from typing import Optional
from enum import Enum


class StackType(str, Enum):
    REACT = "react"
    NEXT = "next"
    VUE = "vue"
    ANGULAR = "angular"


class EnvVar(BaseModel):
    key: str = Field(..., min_length=1, max_length=256)
    value: str = Field(..., max_length=4096)


class DeploymentRequest(BaseModel):
    """Payload generated when user clicks Deploy in the popup."""
    user_id: str
    stack_type: StackType
    github_repo_full_name: str = Field(
        ..., description="owner/repo format", pattern=r"^[a-zA-Z0-9_.-]+/[a-zA-Z0-9_.-]+$"
    )
    branch: str = Field(default="main")
    env_vars: list[EnvVar] = Field(default_factory=list)
    build_command: Optional[str] = Field(default="npm run build")
    output_dir: Optional[str] = Field(default="dist")


class DeploymentResponse(BaseModel):
    deployment_id: str
    status: str
    message: str


class DeploymentStatus(str, Enum):
    QUEUED = "queued"
    BUILDING = "building"
    DEPLOYING = "deploying"
    LIVE = "live"
    FAILED = "failed"
