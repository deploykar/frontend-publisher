import json
import boto3
from app.config import AWS_REGION, SQS_QUEUE_URL

_sqs_client = boto3.client("sqs", region_name=AWS_REGION)


def send_to_queue(payload: dict, deployment_id: str) -> dict:
    """Send deployment job to SQS queue."""
    response = _sqs_client.send_message(
        QueueUrl=SQS_QUEUE_URL,
        MessageBody=json.dumps(payload),
        MessageGroupId=payload.get("github_repo", "default"),
        MessageDeduplicationId=deployment_id,
    )
    return response
