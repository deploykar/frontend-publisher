import uuid
from fastapi import APIRouter, Depends, HTTPException, status
from app.models import DeploymentRequest, DeploymentResponse, DeploymentStatus
from app.auth import get_current_user
from app.queue import send_to_queue

router = APIRouter(prefix="/api/v1/deployments", tags=["deployments"])


@router.post("/", response_model=DeploymentResponse, status_code=status.HTTP_202_ACCEPTED)
async def create_deployment(
    payload: DeploymentRequest,
    current_user: dict = Depends(get_current_user),
):
    """
    Receives the deployment payload from the frontend popup.
    Validates it and pushes a job to SQS.
    """
    if payload.user_id != current_user["user_id"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Cannot deploy on behalf of another user",
        )

    deployment_id = str(uuid.uuid4())

    job_payload = {
        "deployment_id": deployment_id,
        "user_id": payload.user_id,
        "stack_type": payload.stack_type.value,
        "github_repo": payload.github_repo_full_name,
        "branch": payload.branch,
        "env_vars": {ev.key: ev.value for ev in payload.env_vars},
        "build_command": payload.build_command,
        "output_dir": payload.output_dir,
        "github_token": current_user["github_token"],
        "trigger": "manual",
    }

    send_to_queue(job_payload, deployment_id)

    return DeploymentResponse(
        deployment_id=deployment_id,
        status=DeploymentStatus.QUEUED.value,
        message="Deployment queued successfully",
    )
