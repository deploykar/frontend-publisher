import httpx
from datetime import datetime, timedelta, timezone
from fastapi import APIRouter, HTTPException, Query
from jose import jwt
from app.config import (
    GITHUB_CLIENT_ID,
    GITHUB_CLIENT_SECRET,
    JWT_SECRET,
    JWT_ALGORITHM,
)

router = APIRouter(prefix="/api/v1/auth", tags=["auth"])

GITHUB_AUTHORIZE_URL = "https://github.com/login/oauth/authorize"
GITHUB_TOKEN_URL = "https://github.com/login/oauth/access_token"
GITHUB_USER_URL = "https://api.github.com/user"


@router.get("/github")
async def github_login_redirect():
    """
    Frontend calls this to get the GitHub OAuth URL.
    User clicks 'Connect your GitHub' → frontend redirects to this URL.
    """
    scopes = "repo read:user user:email"
    authorize_url = (
        f"{GITHUB_AUTHORIZE_URL}"
        f"?client_id={GITHUB_CLIENT_ID}"
        f"&scope={scopes}"
    )
    return {"authorize_url": authorize_url}


@router.get("/github/callback")
async def github_callback(code: str = Query(...)):
    """
    GitHub redirects back here with a code.
    We exchange it for an access token, fetch user info,
    and return a JWT to the frontend.
    """
    # Exchange code for access token
    async with httpx.AsyncClient() as client:
        token_response = await client.post(
            GITHUB_TOKEN_URL,
            data={
                "client_id": GITHUB_CLIENT_ID,
                "client_secret": GITHUB_CLIENT_SECRET,
                "code": code,
            },
            headers={"Accept": "application/json"},
        )

    if token_response.status_code != 200:
        raise HTTPException(status_code=400, detail="Failed to exchange code for token")

    token_data = token_response.json()
    access_token = token_data.get("access_token")

    if not access_token:
        raise HTTPException(
            status_code=400,
            detail=token_data.get("error_description", "No access token returned"),
        )

    # Fetch GitHub user profile
    async with httpx.AsyncClient() as client:
        user_response = await client.get(
            GITHUB_USER_URL,
            headers={
                "Authorization": f"Bearer {access_token}",
                "Accept": "application/vnd.github+json",
            },
        )

    if user_response.status_code != 200:
        raise HTTPException(status_code=400, detail="Failed to fetch GitHub user info")

    github_user = user_response.json()

    # Build JWT with user info + GitHub token embedded
    jwt_payload = {
        "sub": str(github_user["id"]),
        "username": github_user["login"],
        "avatar_url": github_user.get("avatar_url"),
        "github_token": access_token,
        "iat": datetime.now(timezone.utc),
        "exp": datetime.now(timezone.utc) + timedelta(hours=24),
    }

    token = jwt.encode(jwt_payload, JWT_SECRET, algorithm=JWT_ALGORITHM)

    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": str(github_user["id"]),
            "username": github_user["login"],
            "avatar_url": github_user.get("avatar_url"),
            "name": github_user.get("name"),
        },
    }
