import httpx
from fastapi import APIRouter, Depends, HTTPException
from app.auth import get_current_user

router = APIRouter(prefix="/api/v1/github", tags=["github"])


@router.get("/repos")
async def list_user_repos(current_user: dict = Depends(get_current_user)):
    """
    Fetches the authenticated user's GitHub repos.
    Used by the frontend popup to show repo list.
    """
    github_token = current_user.get("github_token")
    if not github_token:
        raise HTTPException(status_code=400, detail="No GitHub token found in session")

    async with httpx.AsyncClient() as client:
        response = await client.get(
            "https://api.github.com/user/repos",
            headers={
                "Authorization": f"Bearer {github_token}",
                "Accept": "application/vnd.github+json",
            },
            params={"sort": "updated", "per_page": 50},
        )

    if response.status_code != 200:
        raise HTTPException(
            status_code=response.status_code,
            detail="Failed to fetch repos from GitHub",
        )

    repos = response.json()
    return [
        {
            "full_name": repo["full_name"],
            "name": repo["name"],
            "private": repo["private"],
            "default_branch": repo["default_branch"],
            "html_url": repo["html_url"],
            "language": repo["language"],
            "updated_at": repo["updated_at"],
        }
        for repo in repos
    ]


@router.get("/repos/{owner}/{repo}/branches")
async def list_repo_branches(
    owner: str,
    repo: str,
    current_user: dict = Depends(get_current_user),
):
    """Fetch branches for a specific repo."""
    github_token = current_user.get("github_token")

    async with httpx.AsyncClient() as client:
        response = await client.get(
            f"https://api.github.com/repos/{owner}/{repo}/branches",
            headers={
                "Authorization": f"Bearer {github_token}",
                "Accept": "application/vnd.github+json",
            },
            params={"per_page": 30},
        )

    if response.status_code != 200:
        raise HTTPException(
            status_code=response.status_code,
            detail="Failed to fetch branches",
        )

    branches = response.json()
    return [{"name": b["name"]} for b in branches]
