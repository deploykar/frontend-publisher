"""
OAuth proxy — your internal gateway calls these endpoints
instead of calling GitHub directly.
"""
import httpx
from fastapi import APIRouter, Depends, HTTPException, Query
from app.auth import verify_proxy_key
from app.config import GITHUB_CLIENT_ID, GITHUB_CLIENT_SECRET

router = APIRouter(prefix="/proxy/oauth", tags=["oauth"])

GITHUB_AUTHORIZE_URL = "https://github.com/login/oauth/authorize"
GITHUB_TOKEN_URL = "https://github.com/login/oauth/access_token"
GITHUB_USER_URL = "https://api.github.com/user"


@router.get("/authorize-url")
async def get_authorize_url(_=Depends(verify_proxy_key)):
    """Returns the GitHub OAuth URL for the frontend to redirect to."""
    scopes = "repo read:user user:email"
    url = (
        f"{GITHUB_AUTHORIZE_URL}"
        f"?client_id={GITHUB_CLIENT_ID}"
        f"&scope={scopes}"
    )
    return {"authorize_url": url}


@router.post("/exchange-code")
async def exchange_code(code: str = Query(...), _=Depends(verify_proxy_key)):
    """
    Exchange the OAuth code for a GitHub access token.
    Your gateway calls this after GitHub redirects back with the code.
    """
    async with httpx.AsyncClient() as client:
        response = await client.post(
            GITHUB_TOKEN_URL,
            data={
                "client_id": GITHUB_CLIENT_ID,
                "client_secret": GITHUB_CLIENT_SECRET,
                "code": code,
            },
            headers={"Accept": "application/json"},
        )

    if response.status_code != 200:
        raise HTTPException(status_code=400, detail="GitHub token exchange failed")

    data = response.json()
    access_token = data.get("access_token")

    if not access_token:
        raise HTTPException(
            status_code=400,
            detail=data.get("error_description", "No access token returned"),
        )

    # Fetch user profile
    async with httpx.AsyncClient() as client:
        user_resp = await client.get(
            GITHUB_USER_URL,
            headers={
                "Authorization": f"Bearer {access_token}",
                "Accept": "application/vnd.github+json",
            },
        )

    if user_resp.status_code != 200:
        raise HTTPException(status_code=400, detail="Failed to fetch GitHub user")

    user = user_resp.json()

    return {
        "access_token": access_token,
        "user": {
            "id": str(user["id"]),
            "username": user["login"],
            "avatar_url": user.get("avatar_url"),
            "name": user.get("name"),
        },
    }
