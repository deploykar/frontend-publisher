from fastapi import Header, HTTPException
from app.config import PROXY_API_KEY


def verify_proxy_key(x_proxy_key: str = Header(...)):
    """
    Simple API key check — only your internal gateway should know this key.
    Prevents random people from hitting the EC2 proxy.
    """
    if x_proxy_key != PROXY_API_KEY:
        raise HTTPException(status_code=401, detail="Invalid proxy key")
    return True
